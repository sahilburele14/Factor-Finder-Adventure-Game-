let score = 0;
let level = 1;
let streak = 0;
let currentNum1, currentNum2, currentHCF;
let questionsAnswered = 0;
let difficulty = 'easy';

function startGame(selectedDifficulty) {
  difficulty = selectedDifficulty;
  document.getElementById('startScreen').classList.add('hidden');
  document.getElementById('gameScreen').classList.remove('hidden');
  generateQuestion();
}

function getRandomNumber(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function findFactors(num) {
  const factors = [];
  for (let i = 1; i <= num; i++) {
    if (num % i === 0) factors.push(i);
  }
  return factors;
}

function findHCF(num1, num2) {
  const factors1 = findFactors(num1);
  const factors2 = findFactors(num2);
  const commonFactors = factors1.filter(f => factors2.includes(f));
  return Math.max(...commonFactors);
}

function generateQuestion() {
  let max;
  if (difficulty === 'easy') max = 20;
  else if (difficulty === 'medium') max = 50;
  else max = 100;

  do {
    currentNum1 = getRandomNumber(6, max);
    currentNum2 = getRandomNumber(6, max);
    currentHCF = findHCF(currentNum1, currentNum2);
  } while (currentHCF === 1);

  document.getElementById('num1').textContent = currentNum1;
  document.getElementById('num2').textContent = currentNum2;
  document.getElementById('factorNum1').textContent = currentNum1;
  document.getElementById('factorNum2').textContent = currentNum2;

  displayFactors();

  document.getElementById('answerInput').value = '';
  document.getElementById('feedback').style.display = 'none';
  document.getElementById('explanation').classList.add('hidden');
}

function displayFactors() {
  const factors1 = findFactors(currentNum1);
  const factors2 = findFactors(currentNum2);
  const commonFactors = factors1.filter(f => factors2.includes(f));

  const factors1HTML = factors1
    .map(f => `<div class="factor-badge ${commonFactors.includes(f) ? 'common' : ''}">${f}</div>`)
    .join('');

  const factors2HTML = factors2
    .map(f => `<div class="factor-badge ${commonFactors.includes(f) ? 'common' : ''}">${f}</div>`)
    .join('');

  document.getElementById('factors1').innerHTML = factors1HTML;
  document.getElementById('factors2').innerHTML = factors2HTML;
}

function checkAnswer() {
  const userAnswer = parseInt(document.getElementById('answerInput').value);
  const feedbackEl = document.getElementById('feedback');

  if (isNaN(userAnswer)) {
    alert('Please enter a number!');
    return;
  }

  if (userAnswer === currentHCF) {
    feedbackEl.className = 'feedback correct';
    feedbackEl.textContent = '🎉 Correct! Well done!';
    score += 10 * level;
    streak++;

    if (streak % 3 === 0) {
      level++;
      feedbackEl.textContent += ' Level Up! 🚀';
    }
  } else {
    feedbackEl.className = 'feedback incorrect';
    feedbackEl.textContent = `❌ Not quite! The correct answer is ${currentHCF}`;
    streak = 0;
  }

  updateStats();
  showExplanation();
  feedbackEl.style.display = 'block';

  questionsAnswered++;
  if (questionsAnswered >= 10) setTimeout(endGame, 2000);
}

function showExplanation() {
  const factors1 = findFactors(currentNum1);
  const factors2 = findFactors(currentNum2);
  const commonFactors = factors1.filter(f => factors2.includes(f));

  const explanationText = `
    <p>Factors of ${currentNum1}: ${factors1.join(', ')}</p>
    <p>Factors of ${currentNum2}: ${factors2.join(', ')}</p>
    <p><strong>Common Factors:</strong> ${commonFactors.join(', ')}</p>
    <p><strong>HCF:</strong> ${currentHCF}</p>
  `;

  document.getElementById('explanationText').innerHTML = explanationText;
  document.getElementById('explanation').classList.remove('hidden');
}

function showHint() {
  const commonFactors = findFactors(currentNum1).filter(f =>
    findFactors(currentNum2).includes(f)
  );
  alert(`💡 Hint: Look at the common factors — ${commonFactors.join(', ')}`);
}

function updateStats() {
  document.getElementById('score').textContent = score;
  document.getElementById('level').textContent = level;
  document.getElementById('streak').textContent = streak;
}

function nextQuestion() {
  generateQuestion();
}

function endGame() {
  document.getElementById('gameScreen').classList.add('hidden');
  document.getElementById('endScreen').classList.remove('hidden');
  document.getElementById('finalScore').textContent = score;
}

document.addEventListener('DOMContentLoaded', () => {
  const input = document.getElementById('answerInput');
  if (input) {
    input.addEventListener('keypress', e => {
      if (e.key === 'Enter') checkAnswer();
    });
  }
});
